﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PDados
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cbxNumFilhos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void rbtnHomem_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtINSS_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblINSS_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void mskbxNome_Validated(object sender, EventArgs e)
        {

        }

        private void mskbxNome_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskbxSalarioBruto_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void lblNome_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_4(object sender, EventArgs e)
        {

        }

        private void label2_Click_2(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void label1_Click_5(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void mskbxNome_Validated_1(object sender, EventArgs e)
        {
            if ((mskbxNome.Text == "") || (mskbxNome.Text.Length < 10))
            {
                MessageBox.Show("Nome Inválido");
                mskbxNome.Focus();
            }

        }

        private void btnVerificarDescontos_Click(object sender, EventArgs e)
        {
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double descontoINSS=0;
            double descontoIR=0;
            if (double.TryParse(mskbxSalarioBruto.Text.Replace("R$", "").Trim(), out salarioBruto))
            {
                if (salarioBruto <= 0)
                    MessageBox.Show("Salario Bruto inválido");
                else
                {
                    if (salarioBruto <= 800.47)
                    {
                        txtINSS.Text = "7.65%";
                        descontoINSS = 0.075 * salarioBruto;
                    }
                    else

                        if (salarioBruto <= 1050)
                    {
                        txtINSS.Text = "8.65%";
                        descontoINSS = 0.0865 * salarioBruto;
                    }

                    else

                        if (salarioBruto <= 1400.77)
                    {
                        txtINSS.Text = "9%";
                        descontoINSS = 0.09 * salarioBruto;
                    }

                    else

                        if (salarioBruto <= 2081.56)
                    {
                        txtINSS.Text = "11%";
                        descontoINSS = 0.11 * salarioBruto;
                    }
                    else

                    {
                        txtINSS.Text = "11%";
                        descontoINSS = 308.17;
                    }
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");
                }
                if (salarioBruto <= 1257.12)
                {
                    txtDescontoIR.Text = "Isento";
                    descontoIR = 0;
                }

                else
                {
                    if (salarioBruto <= 2512.08)
                    {
                        txtIR.Text = "15%";
                        descontoIR = 0.015 * salarioBruto;
                    }
                    else
                    {
                        txtIR.Text = "27.5%";
                        descontoIR = 0.0275 * salarioBruto;

                    }
                    txtDescontoINSS.Text = descontoIR.ToString("N2");
                }
            }
            if(salarioBruto<=435.52)
            {
                salarioFamilia = 22.33 * Convert.ToDouble(cbxNumFilhos.SelectedItem);
                txtSalárioFamília.Text = salarioFamilia.ToString("N2");
            }
           else if (salarioBruto <= 654.61)
            {
                salarioFamilia = 15.74 * Convert.ToDouble(cbxNumFilhos.SelectedItem);
                txtSalárioFamília.Text = salarioFamilia.ToString("N2");
            }
            else
            {
                salarioFamilia = 0;
                txtSalárioFamília.Text = salarioFamilia.ToString("N2");

            }
           
           salarioLiquido=salarioBruto -descontoINSS- descontoIR + salarioFamilia;
            txtSalárioLíquido.Text = salarioLiquido.ToString("N2");
            lblMensagem.Visible = true;
            lblMensagem.Text = ("Descontos do salário");
            lblMensagem.Text = "Descontos do salário" +
                (rbtnFeminino.Checked ? " da Sra " : " do Sr") +
                mskbxNome.Text +
                (ckbxCasado.Checked ? " casado(a)" : " solteiro(a)") +
                " e que tem " + cbxNumFilhos.SelectedItem + " filho(s) são:";
               
        }

        private void rbtnFeminino_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            cbxNumFilhos.SelectedIndex = 0;
        }

        private void cbxNumFilhos_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void lblNumFilhos_Click(object sender, EventArgs e)
        {

        }

        private void ckbxCasado_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void bntSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
