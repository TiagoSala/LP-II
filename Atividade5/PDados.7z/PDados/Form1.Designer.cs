﻿
namespace PDados
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.mskbxNome = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.cbxNumFilhos = new System.Windows.Forms.ComboBox();
            this.lblMensagem = new System.Windows.Forms.Label();
            this.btnVerificarDescontos = new System.Windows.Forms.Button();
            this.lblSalárioFamília = new System.Windows.Forms.Label();
            this.lblAliquotaIR = new System.Windows.Forms.Label();
            this.lblAliquotaINSS = new System.Windows.Forms.Label();
            this.lblSalárioLíquido = new System.Windows.Forms.Label();
            this.txtINSS = new System.Windows.Forms.TextBox();
            this.txtIR = new System.Windows.Forms.TextBox();
            this.txtSalárioLíquido = new System.Windows.Forms.TextBox();
            this.txtSalárioFamília = new System.Windows.Forms.TextBox();
            this.txtDescontoIR = new System.Windows.Forms.TextBox();
            this.txtDescontoINSS = new System.Windows.Forms.TextBox();
            this.lblDescontoIR = new System.Windows.Forms.Label();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMasculino = new System.Windows.Forms.RadioButton();
            this.rbtnFeminino = new System.Windows.Forms.RadioButton();
            this.pnlCasado = new System.Windows.Forms.Panel();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.gbxSexo.SuspendLayout();
            this.pnlCasado.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.BackColor = System.Drawing.Color.Gainsboro;
            this.lblNome.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lblNome.Location = new System.Drawing.Point(-1, 14);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(257, 28);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome do Funcionário";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.BackColor = System.Drawing.Color.Gainsboro;
            this.lblSalarioBruto.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSalarioBruto.Location = new System.Drawing.Point(-1, 74);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(165, 28);
            this.lblSalarioBruto.TabIndex = 2;
            this.lblSalarioBruto.Text = "Salário Bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.BackColor = System.Drawing.Color.Gainsboro;
            this.lblNumFilhos.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lblNumFilhos.Location = new System.Drawing.Point(-1, 120);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(214, 28);
            this.lblNumFilhos.TabIndex = 3;
            this.lblNumFilhos.Text = "Número de Filhos";
            this.lblNumFilhos.Click += new System.EventHandler(this.lblNumFilhos_Click);
            // 
            // mskbxNome
            // 
            this.mskbxNome.Location = new System.Drawing.Point(265, 14);
            this.mskbxNome.Mask = "LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL";
            this.mskbxNome.Name = "mskbxNome";
            this.mskbxNome.Size = new System.Drawing.Size(198, 23);
            this.mskbxNome.TabIndex = 4;
            this.mskbxNome.Validated += new System.EventHandler(this.mskbxNome_Validated_1);
            // 
            // mskbxSalarioBruto
            // 
            this.mskbxSalarioBruto.Location = new System.Drawing.Point(170, 74);
            this.mskbxSalarioBruto.Mask = " $ 99999.99";
            this.mskbxSalarioBruto.Name = "mskbxSalarioBruto";
            this.mskbxSalarioBruto.Size = new System.Drawing.Size(198, 23);
            this.mskbxSalarioBruto.TabIndex = 5;
            // 
            // cbxNumFilhos
            // 
            this.cbxNumFilhos.FormattingEnabled = true;
            this.cbxNumFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14"});
            this.cbxNumFilhos.Location = new System.Drawing.Point(219, 125);
            this.cbxNumFilhos.Name = "cbxNumFilhos";
            this.cbxNumFilhos.Size = new System.Drawing.Size(198, 23);
            this.cbxNumFilhos.TabIndex = 7;
            this.cbxNumFilhos.SelectedIndexChanged += new System.EventHandler(this.cbxNumFilhos_SelectedIndexChanged_1);
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblMensagem.Location = new System.Drawing.Point(0, 195);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(0, 25);
            this.lblMensagem.TabIndex = 8;
            // 
            // btnVerificarDescontos
            // 
            this.btnVerificarDescontos.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.btnVerificarDescontos.Location = new System.Drawing.Point(487, 387);
            this.btnVerificarDescontos.Name = "btnVerificarDescontos";
            this.btnVerificarDescontos.Size = new System.Drawing.Size(248, 66);
            this.btnVerificarDescontos.TabIndex = 9;
            this.btnVerificarDescontos.Text = "Verificar Descontos";
            this.btnVerificarDescontos.UseVisualStyleBackColor = true;
            this.btnVerificarDescontos.Click += new System.EventHandler(this.btnVerificarDescontos_Click);
            // 
            // lblSalárioFamília
            // 
            this.lblSalárioFamília.AutoSize = true;
            this.lblSalárioFamília.BackColor = System.Drawing.Color.Gainsboro;
            this.lblSalárioFamília.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSalárioFamília.Location = new System.Drawing.Point(-1, 376);
            this.lblSalárioFamília.Name = "lblSalárioFamília";
            this.lblSalárioFamília.Size = new System.Drawing.Size(156, 24);
            this.lblSalárioFamília.TabIndex = 12;
            this.lblSalárioFamília.Text = "Salário Família";
            this.lblSalárioFamília.Click += new System.EventHandler(this.label1_Click_4);
            // 
            // lblAliquotaIR
            // 
            this.lblAliquotaIR.AutoSize = true;
            this.lblAliquotaIR.BackColor = System.Drawing.Color.Gainsboro;
            this.lblAliquotaIR.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAliquotaIR.Location = new System.Drawing.Point(-1, 337);
            this.lblAliquotaIR.Name = "lblAliquotaIR";
            this.lblAliquotaIR.Size = new System.Drawing.Size(119, 24);
            this.lblAliquotaIR.TabIndex = 11;
            this.lblAliquotaIR.Text = "AlÍquota IR";
            // 
            // lblAliquotaINSS
            // 
            this.lblAliquotaINSS.AutoSize = true;
            this.lblAliquotaINSS.BackColor = System.Drawing.Color.Gainsboro;
            this.lblAliquotaINSS.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAliquotaINSS.Location = new System.Drawing.Point(-1, 298);
            this.lblAliquotaINSS.Name = "lblAliquotaINSS";
            this.lblAliquotaINSS.Size = new System.Drawing.Size(146, 24);
            this.lblAliquotaINSS.TabIndex = 10;
            this.lblAliquotaINSS.Text = "Alíquota INSS";
            // 
            // lblSalárioLíquido
            // 
            this.lblSalárioLíquido.AutoSize = true;
            this.lblSalárioLíquido.BackColor = System.Drawing.Color.Gainsboro;
            this.lblSalárioLíquido.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSalárioLíquido.Location = new System.Drawing.Point(-1, 415);
            this.lblSalárioLíquido.Name = "lblSalárioLíquido";
            this.lblSalárioLíquido.Size = new System.Drawing.Size(160, 24);
            this.lblSalárioLíquido.TabIndex = 13;
            this.lblSalárioLíquido.Text = "Salário Líquido";
            // 
            // txtINSS
            // 
            this.txtINSS.Enabled = false;
            this.txtINSS.Location = new System.Drawing.Point(183, 294);
            this.txtINSS.Name = "txtINSS";
            this.txtINSS.ReadOnly = true;
            this.txtINSS.Size = new System.Drawing.Size(207, 23);
            this.txtINSS.TabIndex = 14;
            // 
            // txtIR
            // 
            this.txtIR.Enabled = false;
            this.txtIR.Location = new System.Drawing.Point(183, 341);
            this.txtIR.Name = "txtIR";
            this.txtIR.ReadOnly = true;
            this.txtIR.Size = new System.Drawing.Size(207, 23);
            this.txtIR.TabIndex = 15;
            // 
            // txtSalárioLíquido
            // 
            this.txtSalárioLíquido.Enabled = false;
            this.txtSalárioLíquido.Location = new System.Drawing.Point(183, 416);
            this.txtSalárioLíquido.Name = "txtSalárioLíquido";
            this.txtSalárioLíquido.ReadOnly = true;
            this.txtSalárioLíquido.Size = new System.Drawing.Size(207, 23);
            this.txtSalárioLíquido.TabIndex = 17;
            // 
            // txtSalárioFamília
            // 
            this.txtSalárioFamília.Enabled = false;
            this.txtSalárioFamília.Location = new System.Drawing.Point(183, 381);
            this.txtSalárioFamília.Name = "txtSalárioFamília";
            this.txtSalárioFamília.ReadOnly = true;
            this.txtSalárioFamília.Size = new System.Drawing.Size(207, 23);
            this.txtSalárioFamília.TabIndex = 16;
            // 
            // txtDescontoIR
            // 
            this.txtDescontoIR.Enabled = false;
            this.txtDescontoIR.Location = new System.Drawing.Point(581, 358);
            this.txtDescontoIR.Name = "txtDescontoIR";
            this.txtDescontoIR.ReadOnly = true;
            this.txtDescontoIR.Size = new System.Drawing.Size(207, 23);
            this.txtDescontoIR.TabIndex = 21;
            this.txtDescontoIR.TextChanged += new System.EventHandler(this.textBox1_TextChanged_2);
            // 
            // txtDescontoINSS
            // 
            this.txtDescontoINSS.Enabled = false;
            this.txtDescontoINSS.Location = new System.Drawing.Point(581, 324);
            this.txtDescontoINSS.Name = "txtDescontoINSS";
            this.txtDescontoINSS.ReadOnly = true;
            this.txtDescontoINSS.Size = new System.Drawing.Size(207, 23);
            this.txtDescontoINSS.TabIndex = 20;
            this.txtDescontoINSS.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            // 
            // lblDescontoIR
            // 
            this.lblDescontoIR.AutoSize = true;
            this.lblDescontoIR.BackColor = System.Drawing.Color.Gainsboro;
            this.lblDescontoIR.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDescontoIR.Location = new System.Drawing.Point(412, 354);
            this.lblDescontoIR.Name = "lblDescontoIR";
            this.lblDescontoIR.Size = new System.Drawing.Size(133, 24);
            this.lblDescontoIR.TabIndex = 19;
            this.lblDescontoIR.Text = "Desconto IR";
            this.lblDescontoIR.Click += new System.EventHandler(this.label1_Click_5);
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.BackColor = System.Drawing.Color.Gainsboro;
            this.lblDescontoINSS.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDescontoINSS.Location = new System.Drawing.Point(415, 324);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(160, 24);
            this.lblDescontoINSS.TabIndex = 18;
            this.lblDescontoINSS.Text = "Desconto INSS";
            this.lblDescontoINSS.Click += new System.EventHandler(this.label2_Click_2);
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbtnMasculino);
            this.gbxSexo.Controls.Add(this.rbtnFeminino);
            this.gbxSexo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.gbxSexo.Location = new System.Drawing.Point(481, 12);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Size = new System.Drawing.Size(173, 136);
            this.gbxSexo.TabIndex = 22;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbtnMasculino
            // 
            this.rbtnMasculino.AutoSize = true;
            this.rbtnMasculino.Location = new System.Drawing.Point(6, 41);
            this.rbtnMasculino.Name = "rbtnMasculino";
            this.rbtnMasculino.Size = new System.Drawing.Size(121, 29);
            this.rbtnMasculino.TabIndex = 1;
            this.rbtnMasculino.TabStop = true;
            this.rbtnMasculino.Text = "Masculino";
            this.rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // rbtnFeminino
            // 
            this.rbtnFeminino.AutoSize = true;
            this.rbtnFeminino.Location = new System.Drawing.Point(6, 76);
            this.rbtnFeminino.Name = "rbtnFeminino";
            this.rbtnFeminino.Size = new System.Drawing.Size(113, 29);
            this.rbtnFeminino.TabIndex = 0;
            this.rbtnFeminino.TabStop = true;
            this.rbtnFeminino.Text = "Feminino";
            this.rbtnFeminino.UseVisualStyleBackColor = true;
            this.rbtnFeminino.CheckedChanged += new System.EventHandler(this.rbtnFeminino_CheckedChanged);
            // 
            // pnlCasado
            // 
            this.pnlCasado.Controls.Add(this.ckbxCasado);
            this.pnlCasado.Location = new System.Drawing.Point(660, 88);
            this.pnlCasado.Name = "pnlCasado";
            this.pnlCasado.Size = new System.Drawing.Size(134, 39);
            this.pnlCasado.TabIndex = 23;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ckbxCasado.Location = new System.Drawing.Point(18, 7);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(95, 29);
            this.ckbxCasado.TabIndex = 0;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            this.ckbxCasado.CheckedChanged += new System.EventHandler(this.ckbxCasado_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlCasado);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.txtDescontoIR);
            this.Controls.Add(this.txtDescontoINSS);
            this.Controls.Add(this.lblDescontoIR);
            this.Controls.Add(this.lblDescontoINSS);
            this.Controls.Add(this.txtSalárioLíquido);
            this.Controls.Add(this.txtSalárioFamília);
            this.Controls.Add(this.txtIR);
            this.Controls.Add(this.txtINSS);
            this.Controls.Add(this.lblSalárioLíquido);
            this.Controls.Add(this.lblSalárioFamília);
            this.Controls.Add(this.lblAliquotaIR);
            this.Controls.Add(this.lblAliquotaINSS);
            this.Controls.Add(this.btnVerificarDescontos);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.cbxNumFilhos);
            this.Controls.Add(this.mskbxSalarioBruto);
            this.Controls.Add(this.mskbxNome);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.pnlCasado.ResumeLayout(false);
            this.pnlCasado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.MaskedTextBox mskbxNome;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioBruto;
        private System.Windows.Forms.ComboBox cbxNumFilhos;
        private System.Windows.Forms.Label lblMensagem;
        private System.Windows.Forms.Button btnVerificarDescontos;
        private System.Windows.Forms.Label lblSalárioFamília;
        private System.Windows.Forms.Label lblAliquotaIR;
        private System.Windows.Forms.Label lblAliquotaINSS;
        private System.Windows.Forms.Label lblSalárioLíquido;
        private System.Windows.Forms.TextBox txtINSS;
        private System.Windows.Forms.TextBox txtIR;
        private System.Windows.Forms.TextBox txtSalárioLíquido;
        private System.Windows.Forms.TextBox txtSalárioFamília;
        private System.Windows.Forms.TextBox txtDescontoIR;
        private System.Windows.Forms.TextBox txtDescontoINSS;
        private System.Windows.Forms.Label lblDescontoIR;
        private System.Windows.Forms.Label lblDescontoINSS;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.RadioButton rbtnMasculino;
        private System.Windows.Forms.RadioButton rbtnFeminino;
        private System.Windows.Forms.Panel pnlCasado;
        private System.Windows.Forms.CheckBox ckbxCasado;
    }
}

