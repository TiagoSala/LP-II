﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVvolume
{
    public partial class Form1 : Form
    {
        Double raio;
        Double altura;

        public Form1()
        {
            InitializeComponent();
        }

        private void lblRaio_Validated(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Valor raio inválido!");
                txtRaio.Text = "";
                txtRaio.Focus();
            }

            //if ((txtRaio.Text == "") && (txtAltura.Text == ""))
               //- Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtAltura.Text, out altura) &&
                Double.TryParse(txtRaio.Text, out raio))
            {
                double volume;

                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
                //volume = 3.14 * raio * raio * altura;
            }
            else
            { // se desejar pode testar se os valores são menores que zero
                MessageBox.Show("Valores inválidos");
                txtRaio.Focus();
            }
        }

        private void txtRaio_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {// limpar os dados
            txtAltura.Clear();
            txtRaio.Text = "";
            txtVolume.Text = "";
            // txtVolume.Text = String.Empty();

        }
    }
}
