﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoTriangulos
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Text = "";
            txtValorB.Text = "";
            txtValorC.Text = "";

            txtValorA.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtValorA_TextChanged(object sender, EventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorA.Text, out valorA) ||
               !double.TryParse(txtValorB.Text, out valorB) ||
               !double.TryParse(txtValorC.Text, out valorC))
            {
                MessageBox.Show("valores não podem ser letras");
            }
            else
            {
                if (valorA < (valorB + valorC) && valorA > Math.Abs(valorB - valorC) && valorB < (valorA + valorC) &&
                    valorB > Math.Abs(valorA - valorC) && valorC < (valorA + valorB) && valorC > Math.Abs(valorA - valorB))
                {
                    if (valorA == valorB && valorB == valorC)
                    {
                        MessageBox.Show("Triângulo Equilátero");
                    }
                    else
                    {
                        if (valorA == valorB || valorA == valorC || valorC == valorB)
                        {
                            MessageBox.Show("Triângulo Isósceles");
                        }
                        else
                        {
                            MessageBox.Show("Triângulo Escaleno");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Não dá para formar um triângulo com esses valores");
                }
            }

        }
    
    }
}
