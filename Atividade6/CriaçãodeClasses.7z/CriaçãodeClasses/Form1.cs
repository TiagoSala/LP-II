﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CriaçãodeClasses
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMensalista1_Click(object sender, EventArgs e)
        {
            FrmMensalista FRM1 = new FrmMensalista();
            FRM1.Show();//chama o formulario
        }

        private void btnHorista_Click(object sender, EventArgs e)
        {
            FrmHorista FRM1 = new FrmHorista();
            FRM1.Show();//chama o formulario
        }
    }
}
