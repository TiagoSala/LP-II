﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CriaçãodeClasses
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstanciar1_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();
           
            //set
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntrada.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalarioMensal.Text);
            //get
            MessageBox.Show("Matricula:" + objMensalista.Matricula + "\n" +
                "Nome:" + objMensalista.NomeEmpregado + "\n"+
                "Data Entrada" + objMensalista.DataEntradaEmpresa + "\n" +
                "Salario Bruto:" + objMensalista.SalarioBruto() + "\n" +
                "Tempo Trabalho:" + objMensalista.TempoTrabalho());

        }

        private void btnInstanciar2_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(
               Convert.ToInt32(txtMatricula.Text),
               txtNome.Text,
             Convert.ToDateTime(txtDataEntrada.Text),
             Convert.ToDouble(txtSalarioMensal.Text));

            MessageBox.Show("Matricula:" + objMensalista.Matricula + "\n" +
               "Nome:" + objMensalista.NomeEmpregado + "\n" +
               "Data Entrada" + objMensalista.DataEntradaEmpresa + "\n" +
               "Salario Bruto:" + objMensalista.SalarioBruto() + "\n" +
               "Tempo Trabalho:" + objMensalista.TempoTrabalho());


        }

        private void FrmMensalista_Load(object sender, EventArgs e)
        {

        }
    }
}
