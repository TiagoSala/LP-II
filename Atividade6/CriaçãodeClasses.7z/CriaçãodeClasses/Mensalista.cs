﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CriaçãodeClasses
{
    class Mensalista:Empregado
    {
        //propriedade
        public double SalarioMensal { get; set; }
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
        //Construtor
        public Mensalista()
        {
            //System.Windows.Forms.MessageBox.Show("Passa por aqui");
        }
        public Mensalista(int matx,string nomex,DateTime datax,double salx)
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = datax;
            SalarioMensal = salx;
        }
        public int Soma(int x,int y)
        {
            return x + y;
        }
        public int Soma(int x,int y,int z)
        {
            return x + y + z;
        }
    }
}
